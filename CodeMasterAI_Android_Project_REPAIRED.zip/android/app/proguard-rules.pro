# Code Master AI release rules. Add keep rules only when required by tested libraries.
